package com.emp.management.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.emp.management.model.Employee;

import java.util.ArrayList;
import java.util.List;

@Repository
public class EmployeeDaoImp implements EmployeeDAO {

	@Override
	public void addEmployee(Employee employee) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;

		tx = session.beginTransaction();

		session.save(employee);

		tx.commit();
	}

	@Override
	public void updateEmployee(Employee employee) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;

		tx = session.beginTransaction();

		session.update(employee);

		tx.commit();
	}

	@Override
	public void deleteEmployee(int id) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;

		tx = session.beginTransaction();

		session.delete(new Employee(id));

		tx.commit();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> emps = new ArrayList<Employee>();
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;

		tx = session.beginTransaction();

		emps = session.createQuery("from Employee").list();

		tx.commit();
		return emps;

	}

	@Override
	public Employee getEmployeeById(int id) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();

		Transaction tx = null;

		tx = session.beginTransaction();

		Employee emp = session.get(Employee.class, id);

		tx.commit();
		return emp;
	}
}
