package com.emp.management.dao;

import java.util.List;

import com.emp.management.model.Employee;

public interface EmployeeDAO {

	void addEmployee(Employee employee);
	void updateEmployee(Employee employee);
	void deleteEmployee(int id);
	List<Employee> getAllEmployees();
	Employee getEmployeeById(int id);
	
}
