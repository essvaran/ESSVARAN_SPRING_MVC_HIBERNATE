package com.emp.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.emp.management.model.Employee;
import com.emp.management.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeService service;
	
	@RequestMapping("/")
	public String welcome(Model m)
	{
		List<Employee> employees = service.getAllEmployees();
		m.addAttribute("employees",employees);
		return "home";
	}
	
	@RequestMapping("/employee/list")
	public String showEmployees(Model model)
	{
		List<Employee> employees = service.getAllEmployees();
		model.addAttribute("employees",employees);
		return "all-employees";
	}
	@RequestMapping("/employee/add")
	public String addEmployeeForm()
	{
		return "Form";
	}
	
	@PostMapping("/employee/insert")
	public String insert(@RequestParam String name, @RequestParam String address , @RequestParam String phone , @RequestParam String salary , Model  model) 
	{
		service.addEmployee(new Employee(0, name, address, phone, salary));
		List<Employee> employees = service.getAllEmployees();
		model.addAttribute("employees",employees);
		return "all-employees";
	}
	
	@PostMapping("/employee/delete")
	public String delete(Model model , @RequestParam int id)
	{
		service.deleteEmployee(id);
		List<Employee> employees = service.getAllEmployees();
		model.addAttribute("employees",employees);
		return "all-employees";
	}
	
	@PostMapping("/employee/update")
	public String update(Model model , @RequestParam int id)
	{
		Employee e = service.getEmployeeById(id);
		model.addAttribute("employee", e);
		return "update-form";
	}
	
	@PostMapping("/employee/fupdate")
	public String finalUpdate(@RequestParam int id,@RequestParam String name, @RequestParam String address , @RequestParam String phone , @RequestParam String salary , Model  model) 
	{
		service.updateEmployee(new Employee(id, name, address, phone, salary));
		List<Employee> employees = service.getAllEmployees();
		model.addAttribute("employees",employees);
		return "all-employees";
	}
}
