package com.emp.management.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String empName;
	private String empAddress;
	private String empPhone;
	private String empSalary;

	// Constructor with all the parameters
	public Employee(int id, String empName, String empAddress, String empPhone, String empSalary) {
		this.id = id;
		this.empName = empName;
		this.empAddress = empAddress;
		this.empPhone = empPhone;
		this.empSalary = empSalary;
	}

	// Constructor with one parameter - for delete operation
	public Employee(int id) {
		this.id = id;
	}

	// default constructor
	public Employee() {
	}

	// Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public String getEmpPhone() {
		return empPhone;
	}

	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}

	public String getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}

}
