package com.emp.management.service;

import java.util.List;

import com.emp.management.model.Employee;

public interface EmployeeService {

	void addEmployee(Employee employee);
	void updateEmployee(Employee employee);
	void deleteEmployee(int id);
	List<Employee> getAllEmployees();
	Employee getEmployeeById(int id);
}
